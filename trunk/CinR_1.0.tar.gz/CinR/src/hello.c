#include <math.h>;
#include <io.h>;

void hello(int *n)
{
int i;
for(i=0; i < *n; i++) {
Rprintf("hey, world!\n");
}
}

#include <math.h>;
#include <io.h>;

void hey(int *n)
{
int i;
for(i=0; i < *n; i++) {
Rprintf("hey, hey!\n");
}
}
